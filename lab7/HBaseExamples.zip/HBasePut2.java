package hbase;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
import org.apache.hadoop.hbase.client.Put;
import org.apache.hadoop.hbase.client.Table;
import org.apache.hadoop.hbase.util.Bytes;

public class HBasePut2 {

	public static void main(String[] args) throws IOException {
		Configuration config = HBaseConfiguration.create();
		Connection connection = ConnectionFactory.createConnection(config);
		Table table = connection.getTable(TableName.valueOf("lsu"));

		try {
			Put put = new Put(Bytes.toBytes("DDD"));
			byte[] columnFamily = Bytes.toBytes("grades");
			byte[] qualifier = Bytes.toBytes("gpa");
			byte[] value = Bytes.toBytes("3.0");
			put.addImmutable(columnFamily, qualifier, value);
			put.addImmutable(columnFamily, Bytes.toBytes("oldgpa"), Bytes.toBytes("2"));
			put.addImmutable(Bytes.toBytes("info"), Bytes.toBytes("age"), Bytes.toBytes("21"));
			table.put(put);
		} finally {
			table.close();
			connection.close();
		}

	}

}
